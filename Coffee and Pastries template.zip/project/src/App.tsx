import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './contexts/CartContext';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import Menu from './components/Menu';
import OurStory from './components/OurStory';
import VisitUs from './components/VisitUs';
import Gallery from './components/Gallery';
import Newsletter from './components/Newsletter';

function App() {
  return (
    <CartProvider>
      <Router>
        <div className="min-h-screen bg-cream-50">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/menu" element={<Menu />} />
              <Route path="/our-story" element={<OurStory />} />
              <Route path="/visit-us" element={<VisitUs />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route path="/newsletter" element={<Newsletter />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;