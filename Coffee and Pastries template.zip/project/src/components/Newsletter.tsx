import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Gift, Coffee, Leaf, Bell } from 'lucide-react';

const Newsletter = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      setEmail('');
    }
  };

  const benefits = [
    {
      icon: <Gift className="h-8 w-8 text-moss-600" />,
      title: "15% Off Welcome Discount",
      description: "Get an instant discount on your first order"
    },
    {
      icon: <Coffee className="h-8 w-8 text-moss-600" />,
      title: "Weekly Specials",
      description: "Be the first to know about new drinks and seasonal items"
    },
    {
      icon: <Bell className="h-8 w-8 text-moss-600" />,
      title: "Event Invitations",
      description: "Exclusive access to tastings, workshops, and community events"
    },
    {
      icon: <Leaf className="h-8 w-8 text-moss-600" />,
      title: "Sustainability Updates",
      description: "Learn about our environmental initiatives and impact"
    }
  ];

  return (
    <div className="pt-16 min-h-screen bg-cream-50">
      {/* Hero Section */}
      <section className="bg-coffee-800 text-white py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl font-bold mb-6">Stay Connected</h1>
            <p className="text-xl text-cream-100">
              Join our coffee community and never miss a brew-tiful moment
            </p>
          </motion.div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center"
          >
            {!isSubmitted ? (
              <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12">
                <div className="flex justify-center mb-6">
                  <div className="bg-moss-100 p-4 rounded-full">
                    <Mail className="h-12 w-12 text-moss-600" />
                  </div>
                </div>
                <h2 className="text-4xl font-bold text-coffee-800 mb-4">
                  Get 15% Off Your First Order
                </h2>
                <p className="text-xl text-coffee-600 mb-8">
                  Join our newsletter and be part of the Brew & Bloom family
                </p>

                <form onSubmit={handleSubmit} className="max-w-md mx-auto">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      className="flex-1 px-6 py-4 border border-cream-300 rounded-full focus:outline-none focus:ring-2 focus:ring-coffee-600 focus:border-transparent text-coffee-800"
                      required
                    />
                    <button
                      type="submit"
                      className="bg-coffee-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-coffee-700 transform hover:scale-105 transition-all duration-300 shadow-lg"
                    >
                      Subscribe
                    </button>
                  </div>
                </form>

                <p className="text-sm text-coffee-500 mt-4">
                  We respect your privacy. Unsubscribe at any time.
                </p>
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="bg-white rounded-3xl shadow-2xl p-8 md:p-12"
              >
                <div className="flex justify-center mb-6">
                  <div className="bg-moss-100 p-4 rounded-full">
                    <Coffee className="h-12 w-12 text-moss-600" />
                  </div>
                </div>
                <h2 className="text-4xl font-bold text-coffee-800 mb-4">
                  Welcome to the Family!
                </h2>
                <p className="text-xl text-coffee-600 mb-6">
                  Check your email for your 15% discount code
                </p>
                <div className="bg-moss-100 p-6 rounded-2xl">
                  <p className="text-coffee-700 font-medium">
                    Your discount code will arrive shortly. Start browsing our menu to plan your first discounted order!
                  </p>
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-coffee-800 mb-4">Why Subscribe?</h2>
            <p className="text-xl text-coffee-600">
              Enjoy exclusive perks and stay connected with our coffee community
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="text-center p-6 rounded-2xl bg-cream-50 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex justify-center mb-4">{benefit.icon}</div>
                <h3 className="text-xl font-bold text-coffee-800 mb-3">{benefit.title}</h3>
                <p className="text-coffee-600">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20 bg-moss-100">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-coffee-800 mb-8">Join 2,500+ Coffee Lovers</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <p className="text-coffee-600 italic mb-4">
                  "Love getting the weekly specials in my inbox. Never miss a new seasonal drink!"
                </p>
                <p className="font-semibold text-coffee-800">- Sarah M.</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <p className="text-coffee-600 italic mb-4">
                  "The sustainability updates keep me informed about their environmental impact."
                </p>
                <p className="font-semibold text-coffee-800">- David L.</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <p className="text-coffee-600 italic mb-4">
                  "The event invitations are amazing. Met so many fellow coffee enthusiasts!"
                </p>
                <p className="font-semibold text-coffee-800">- Maria K.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Newsletter;