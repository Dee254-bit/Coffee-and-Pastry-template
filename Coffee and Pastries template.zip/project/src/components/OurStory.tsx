import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Leaf, Users, Award } from 'lucide-react';

const OurStory = () => {
  return (
    <div className="pt-16 min-h-screen bg-cream-50">
      {/* Hero Section */}
      <section className="bg-coffee-800 text-white py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl font-bold mb-6">Our Story</h1>
            <p className="text-xl text-cream-100">
              A passion for coffee, community, and sustainability
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Story */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img
                src="https://images.pexels.com/photos/4350057/pexels-photo-4350057.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Coffee roasting"
                className="rounded-2xl shadow-2xl"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl font-bold text-coffee-800 mb-6">Where It All Began</h2>
              <p className="text-lg text-coffee-600 mb-6">
                Founded in 2018 by Sarah Chen and Marcus Rodriguez, Brew & Bloom started as a dream to create more than just another coffee shop. We envisioned a space where exceptional coffee meets genuine community connection.
              </p>
              <p className="text-lg text-coffee-600 mb-6">
                After years of traveling and experiencing coffee cultures around the world, we returned home with a mission: to bring the finest beans to our neighborhood while supporting the farmers who grow them through direct trade partnerships.
              </p>
              <p className="text-lg text-coffee-600">
                Today, Brew & Bloom has become a beloved gathering place where friends meet, ideas bloom, and every cup tells a story of sustainability and quality.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-coffee-800 mb-4">Our Mission & Values</h2>
            <p className="text-xl text-coffee-600 max-w-3xl mx-auto">
              Every decision we make is guided by our commitment to quality, community, and environmental responsibility
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Heart className="h-12 w-12 text-moss-600" />,
                title: "Community First",
                description: "Building connections and supporting local initiatives that strengthen our neighborhood"
              },
              {
                icon: <Leaf className="h-12 w-12 text-moss-600" />,
                title: "Sustainability",
                description: "From compostable cups to renewable energy, we're committed to protecting our planet"
              },
              {
                icon: <Award className="h-12 w-12 text-moss-600" />,
                title: "Quality Excellence",
                description: "Sourcing the finest beans and crafting each drink with precision and care"
              },
              {
                icon: <Users className="h-12 w-12 text-moss-600" />,
                title: "Fair Trade",
                description: "Supporting coffee farmers through direct partnerships and fair compensation"
              }
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="text-center p-6 rounded-2xl bg-cream-50 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex justify-center mb-4">{value.icon}</div>
                <h3 className="text-xl font-bold text-coffee-800 mb-3">{value.title}</h3>
                <p className="text-coffee-600">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Sustainability Focus */}
      <section className="py-20 bg-moss-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl font-bold text-coffee-800 mb-6">Our Sustainability Promise</h2>
              <p className="text-lg text-coffee-600 mb-6">
                We believe great coffee shouldn't come at the expense of our environment. That's why we've implemented comprehensive sustainability practices throughout our operations.
              </p>
              <ul className="space-y-4 text-coffee-600">
                <li className="flex items-start">
                  <Leaf className="h-5 w-5 text-moss-600 mt-1 mr-3 flex-shrink-0" />
                  <span>100% compostable cups, lids, and packaging materials</span>
                </li>
                <li className="flex items-start">
                  <Leaf className="h-5 w-5 text-moss-600 mt-1 mr-3 flex-shrink-0" />
                  <span>Solar-powered roasting equipment and renewable energy</span>
                </li>
                <li className="flex items-start">
                  <Leaf className="h-5 w-5 text-moss-600 mt-1 mr-3 flex-shrink-0" />
                  <span>Direct trade partnerships with sustainable coffee farms</span>
                </li>
                <li className="flex items-start">
                  <Leaf className="h-5 w-5 text-moss-600 mt-1 mr-3 flex-shrink-0" />
                  <span>Zero-waste goal with comprehensive recycling and composting</span>
                </li>
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img
                src="https://images.pexels.com/photos/4050328/pexels-photo-4050328.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Sustainable practices"
                className="rounded-2xl shadow-2xl"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Founders Note */}
      <section className="py-20 bg-coffee-800 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-8">A Note from Our Founders</h2>
            <blockquote className="text-xl italic text-cream-100 mb-8">
              "When we opened Brew & Bloom, we dreamed of creating a space where every person feels welcome, every cup is crafted with intention, and every choice we make contributes to a better world. Thank you for being part of our journey and helping us build something beautiful together."
            </blockquote>
            <div className="flex justify-center space-x-8">
              <div>
                <p className="font-semibold text-lg">Sarah Chen</p>
                <p className="text-moss-400">Co-Founder & Head Roaster</p>
              </div>
              <div>
                <p className="font-semibold text-lg">Marcus Rodriguez</p>
                <p className="text-moss-400">Co-Founder & Operations</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default OurStory;