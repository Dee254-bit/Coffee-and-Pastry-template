import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Clock, Star, Leaf } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';

const Home = () => {
  const { addItem } = useCart();

  const dailySpecials = [
    {
      name: "Autumn Spice Latte",
      description: "Pumpkin spice with oat milk",
      price: "$4.75",
      image: "https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Blueberry Scone",
      description: "Fresh baked with local berries",
      price: "$3.25",
      image: "https://images.pexels.com/photos/1191639/pexels-photo-1191639.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Avocado Toast",
      description: "Sourdough with hemp seeds",
      price: "$8.50",
      image: "https://images.pexels.com/photos/566566/pexels-photo-566566.jpeg?auto=compress&cs=tinysrgb&w=400"
    }
  ];

  const handleAddSpecialToCart = (special: any) => {
    const cartItem = {
      id: `special-${special.name.toLowerCase().replace(/\s+/g, '-')}`,
      name: special.name,
      price: parseFloat(special.price.replace('$', '')),
      image: special.image,
      category: 'specials'
    };
    addItem(cartItem);
  };

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/1833586/pexels-photo-1833586.jpeg?auto=compress&cs=tinysrgb&w=1600)'
          }}
        >
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="relative z-10 text-center text-white max-w-4xl mx-auto px-4"
        >
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            Where Coffee
            <span className="block text-moss-400">Meets Community</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-cream-100">
            Artisan roasted coffee, fresh pastries, and sustainable practices in the heart of your neighborhood
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-coffee-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-coffee-700 transform hover:scale-105 transition-all duration-300 shadow-xl">
              Order Now
            </button>
            <Link
              to="/menu"
              className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-coffee-800 transition-all duration-300"
            >
              View Menu
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-coffee-800 mb-4">Why Choose Brew & Bloom?</h2>
            <p className="text-xl text-coffee-600 max-w-2xl mx-auto">
              We're more than just a coffee shop - we're your neighborhood gathering place
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Star className="h-12 w-12 text-moss-600" />,
                title: "Premium Quality",
                description: "Single-origin beans roasted weekly in small batches"
              },
              {
                icon: <Leaf className="h-12 w-12 text-moss-600" />,
                title: "Sustainable Practices",
                description: "Eco-friendly packaging and direct trade partnerships"
              },
              {
                icon: <Clock className="h-12 w-12 text-moss-600" />,
                title: "Always Fresh",
                description: "Pastries baked daily and coffee brewed to perfection"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="text-center p-8 rounded-2xl bg-cream-50 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex justify-center mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold text-coffee-800 mb-2">{feature.title}</h3>
                <p className="text-coffee-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Daily Specials */}
      <section className="py-20 bg-cream-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-coffee-800 mb-4">Today's Specials</h2>
            <p className="text-xl text-coffee-600">
              Fresh flavors crafted daily by our expert baristas
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {dailySpecials.map((special, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transform hover:-translate-y-2 transition-all duration-300"
              >
                <img
                  src={special.image}
                  alt={special.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-coffee-800">{special.name}</h3>
                    <span className="text-2xl font-bold text-moss-600">{special.price}</span>
                  </div>
                  <p className="text-coffee-600 mb-4">{special.description}</p>
                  <button 
                    onClick={() => handleAddSpecialToCart(special)}
                    className="w-full bg-coffee-600 text-white py-2 rounded-lg font-medium hover:bg-coffee-700 transform hover:scale-105 transition-all duration-200 shadow-lg"
                  >
                    Add to Order
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-coffee-800 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-6">Ready to Experience Brew & Bloom?</h2>
            <p className="text-xl mb-8 text-cream-100">
              Join our community of coffee lovers and taste the difference quality makes
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/visit-us"
                className="bg-moss-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-moss-700 transform hover:scale-105 transition-all duration-300 inline-flex items-center justify-center"
              >
                Find Us <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/newsletter"
                className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-coffee-800 transition-all duration-300"
              >
                Get Updates
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;