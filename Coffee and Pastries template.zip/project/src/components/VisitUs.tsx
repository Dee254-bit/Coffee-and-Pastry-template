import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Phone, Mail, Wifi, Car } from 'lucide-react';

const VisitUs = () => {
  const hours = [
    { day: 'Monday - Friday', time: '6:00 AM - 8:00 PM' },
    { day: 'Saturday', time: '7:00 AM - 9:00 PM' },
    { day: 'Sunday', time: '7:00 AM - 7:00 PM' }
  ];

  const amenities = [
    { icon: <Wifi className="h-6 w-6" />, name: 'Free Wi-Fi' },
    { icon: <Car className="h-6 w-6" />, name: 'Parking Available' },
    { icon: <MapPin className="h-6 w-6" />, name: 'Transit Accessible' }
  ];

  return (
    <div className="pt-16 min-h-screen bg-cream-50">
      {/* Hero Section */}
      <section className="bg-coffee-800 text-white py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl font-bold mb-6">Visit Us</h1>
            <p className="text-xl text-cream-100">
              Come experience the warmth of our community coffee house
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-coffee-800 mb-8">Find Us</h2>
              
              {/* Address */}
              <div className="mb-8">
                <div className="flex items-start space-x-4 p-6 bg-white rounded-2xl shadow-lg">
                  <MapPin className="h-8 w-8 text-moss-600 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-xl font-semibold text-coffee-800 mb-2">Address</h3>
                    <p className="text-coffee-600">
                      1247 Elm Street<br />
                      Coffee District<br />
                      Portland, OR 97205
                    </p>
                  </div>
                </div>
              </div>

              {/* Hours */}
              <div className="mb-8">
                <div className="p-6 bg-white rounded-2xl shadow-lg">
                  <div className="flex items-center space-x-4 mb-4">
                    <Clock className="h-8 w-8 text-moss-600" />
                    <h3 className="text-xl font-semibold text-coffee-800">Hours</h3>
                  </div>
                  <div className="space-y-3">
                    {hours.map((schedule, index) => (
                      <div key={index} className="flex justify-between">
                        <span className="text-coffee-600">{schedule.day}</span>
                        <span className="font-medium text-coffee-800">{schedule.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Contact */}
              <div className="grid sm:grid-cols-2 gap-4 mb-8">
                <div className="p-6 bg-white rounded-2xl shadow-lg">
                  <div className="flex items-center space-x-4 mb-2">
                    <Phone className="h-6 w-6 text-moss-600" />
                    <h3 className="text-lg font-semibold text-coffee-800">Phone</h3>
                  </div>
                  <p className="text-coffee-600">(503) 555-BREW</p>
                </div>
                <div className="p-6 bg-white rounded-2xl shadow-lg">
                  <div className="flex items-center space-x-4 mb-2">
                    <Mail className="h-6 w-6 text-moss-600" />
                    <h3 className="text-lg font-semibold text-coffee-800">Email</h3>
                  </div>
                  <p className="text-coffee-600">hello@brewandbloom.com</p>
                </div>
              </div>

              {/* Amenities */}
              <div className="p-6 bg-moss-100 rounded-2xl">
                <h3 className="text-xl font-semibold text-coffee-800 mb-4">Amenities</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="text-moss-600">{amenity.icon}</div>
                      <span className="text-coffee-600">{amenity.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Map */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="lg:sticky lg:top-24"
            >
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="h-96 bg-gradient-to-br from-moss-200 to-coffee-200 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-16 w-16 text-moss-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-coffee-800 mb-2">Interactive Map</h3>
                    <p className="text-coffee-600">Google Maps integration would appear here</p>
                    <button className="mt-4 bg-coffee-600 text-white px-6 py-2 rounded-lg hover:bg-coffee-700 transition-colors duration-200">
                      Get Directions
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Special Notes */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-coffee-800 mb-6">Plan Your Visit</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="p-6 bg-cream-50 rounded-2xl">
                <h3 className="text-xl font-semibold text-coffee-800 mb-3">Busy Times</h3>
                <p className="text-coffee-600">
                  Our busiest hours are typically 7-9 AM and 12-2 PM on weekdays. For a quieter experience, visit us mid-morning or afternoon.
                </p>
              </div>
              <div className="p-6 bg-cream-50 rounded-2xl">
                <h3 className="text-xl font-semibold text-coffee-800 mb-3">Group Events</h3>
                <p className="text-coffee-600">
                  Planning a meeting or celebration? We offer space for small groups and can accommodate special requests with advance notice.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default VisitUs;