import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, ShoppingBag, Trash2 } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartSidebar: React.FC<CartSidebarProps> = ({ isOpen, onClose }) => {
  const { state, removeItem, updateQuantity, clearCart } = useCart();

  const handleCheckout = () => {
    alert('Checkout functionality would be implemented here with payment processing!');
    clearCart();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40"
            onClick={onClose}
          />
          
          {/* Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-cream-200">
              <div className="flex items-center space-x-2">
                <ShoppingBag className="h-6 w-6 text-coffee-600" />
                <h2 className="text-xl font-bold text-coffee-800">Your Order</h2>
                {state.itemCount > 0 && (
                  <span className="bg-coffee-600 text-white text-sm px-2 py-1 rounded-full">
                    {state.itemCount}
                  </span>
                )}
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-cream-100 rounded-full transition-colors duration-200"
              >
                <X className="h-6 w-6 text-coffee-600" />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-6">
              {state.items.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag className="h-16 w-16 text-cream-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-coffee-600 mb-2">Your cart is empty</h3>
                  <p className="text-coffee-500">Add some delicious items to get started!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {state.items.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex items-center space-x-4 bg-cream-50 p-4 rounded-xl"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-coffee-800">{item.name}</h4>
                        <p className="text-sm text-coffee-600 capitalize">{item.category}</p>
                        <p className="font-bold text-moss-600">${item.price.toFixed(2)}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-cream-200 rounded-full transition-colors duration-200"
                        >
                          <Minus className="h-4 w-4 text-coffee-600" />
                        </button>
                        <span className="w-8 text-center font-medium text-coffee-800">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-cream-200 rounded-full transition-colors duration-200"
                        >
                          <Plus className="h-4 w-4 text-coffee-600" />
                        </button>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="p-1 hover:bg-red-100 rounded-full transition-colors duration-200 ml-2"
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {state.items.length > 0 && (
              <div className="border-t border-cream-200 p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium text-coffee-800">Total:</span>
                  <span className="text-2xl font-bold text-moss-600">
                    ${state.total.toFixed(2)}
                  </span>
                </div>
                
                <div className="space-y-3">
                  <button
                    onClick={handleCheckout}
                    className="w-full bg-coffee-600 text-white py-3 rounded-xl font-semibold hover:bg-coffee-700 transform hover:scale-105 transition-all duration-300 shadow-lg"
                  >
                    Checkout
                  </button>
                  <button
                    onClick={clearCart}
                    className="w-full border-2 border-cream-300 text-coffee-600 py-3 rounded-xl font-medium hover:bg-cream-100 transition-colors duration-200"
                  >
                    Clear Cart
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartSidebar;