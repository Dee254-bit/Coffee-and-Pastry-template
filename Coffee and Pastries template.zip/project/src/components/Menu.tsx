import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Coffee, Leaf, Utensils, Cookie } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('coffee');
  const { addItem } = useCart();

  const categories = [
    { id: 'coffee', name: 'Coffee', icon: <Coffee className="h-6 w-6" /> },
    { id: 'tea', name: 'Tea', icon: <Leaf className="h-6 w-6" /> },
    { id: 'pastries', name: 'Pastries', icon: <Cookie className="h-6 w-6" /> },
    { id: 'sandwiches', name: 'Sandwiches', icon: <Utensils className="h-6 w-6" /> }
  ];

  const handleAddToCart = (item: any, category: string) => {
    const cartItem = {
      id: `${category}-${item.name.toLowerCase().replace(/\s+/g, '-')}`,
      name: item.name,
      price: parseFloat(item.price.replace('$', '')),
      image: item.image,
      category: category
    };
    addItem(cartItem);
  };

  const menuItems = {
    coffee: [
      { 
        name: 'Espresso', 
        description: 'Rich and bold single shot', 
        price: '$2.50',
        image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Americano', 
        description: 'Espresso with hot water', 
        price: '$3.25',
        image: 'https://images.pexels.com/photos/1251175/pexels-photo-1251175.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Cappuccino', 
        description: 'Equal parts espresso, steamed milk, and foam', 
        price: '$4.50',
        image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Latte', 
        description: 'Espresso with steamed milk and light foam', 
        price: '$4.75',
        image: 'https://images.pexels.com/photos/324028/pexels-photo-324028.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Mocha', 
        description: 'Espresso with chocolate and steamed milk', 
        price: '$5.25',
        image: 'https://images.pexels.com/photos/1458671/pexels-photo-1458671.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Cold Brew', 
        description: 'Smooth, slow-steeped coffee served cold', 
        price: '$3.75',
        image: 'https://images.pexels.com/photos/1233528/pexels-photo-1233528.jpeg?auto=compress&cs=tinysrgb&w=400'
      }
    ],
    tea: [
      { 
        name: 'Earl Grey', 
        description: 'Classic bergamot-infused black tea', 
        price: '$3.25',
        image: 'https://images.pexels.com/photos/1638280/pexels-photo-1638280.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Green Tea', 
        description: 'Organic Japanese sencha', 
        price: '$3.00',
        image: 'https://images.pexels.com/photos/1417945/pexels-photo-1417945.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Chamomile', 
        description: 'Soothing herbal blend', 
        price: '$3.25',
        image: 'https://images.pexels.com/photos/1638281/pexels-photo-1638281.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Chai Latte', 
        description: 'Spiced black tea with steamed milk', 
        price: '$4.25',
        image: 'https://images.pexels.com/photos/1793037/pexels-photo-1793037.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Matcha Latte', 
        description: 'Premium ceremonial grade matcha', 
        price: '$4.75',
        image: 'https://images.pexels.com/photos/4021779/pexels-photo-4021779.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Herbal Mint', 
        description: 'Fresh peppermint leaves', 
        price: '$3.00',
        image: 'https://images.pexels.com/photos/1638280/pexels-photo-1638280.jpeg?auto=compress&cs=tinysrgb&w=400'
      }
    ],
    pastries: [
      { 
        name: 'Croissant', 
        description: 'Buttery, flaky French pastry', 
        price: '$3.25',
        image: 'https://images.pexels.com/photos/2135/food-france-morning-breakfast.jpg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Blueberry Muffin', 
        description: 'Made with fresh local blueberries', 
        price: '$3.75',
        image: 'https://images.pexels.com/photos/1191639/pexels-photo-1191639.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Chocolate Chip Cookie', 
        description: 'Warm, gooey, and irresistible', 
        price: '$2.50',
        image: 'https://images.pexels.com/photos/230325/pexels-photo-230325.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Cinnamon Roll', 
        description: 'Sweet and sticky with cream cheese frosting', 
        price: '$4.25',
        image: 'https://images.pexels.com/photos/1055272/pexels-photo-1055272.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Scone', 
        description: 'Traditional English-style with jam', 
        price: '$3.50',
        image: 'https://images.pexels.com/photos/1055271/pexels-photo-1055271.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Danish', 
        description: 'Flaky pastry with seasonal fruit', 
        price: '$3.75',
        image: 'https://images.pexels.com/photos/1055270/pexels-photo-1055270.jpeg?auto=compress&cs=tinysrgb&w=400'
      }
    ],
    sandwiches: [
      { 
        name: 'Avocado Toast', 
        description: 'Smashed avocado on sourdough with hemp seeds', 
        price: '$8.50',
        image: 'https://images.pexels.com/photos/566566/pexels-photo-566566.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Grilled Cheese', 
        description: 'Three cheese blend on artisan bread', 
        price: '$7.25',
        image: 'https://images.pexels.com/photos/461198/pexels-photo-461198.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Turkey Club', 
        description: 'Roasted turkey, bacon, lettuce, tomato', 
        price: '$9.75',
        image: 'https://images.pexels.com/photos/1633525/pexels-photo-1633525.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Veggie Wrap', 
        description: 'Hummus, sprouts, cucumber, and greens', 
        price: '$8.25',
        image: 'https://images.pexels.com/photos/1059905/pexels-photo-1059905.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'BLT', 
        description: 'Crispy bacon, lettuce, tomato on toasted bread', 
        price: '$8.75',
        image: 'https://images.pexels.com/photos/1633578/pexels-photo-1633578.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      { 
        name: 'Caprese', 
        description: 'Fresh mozzarella, basil, tomato, balsamic', 
        price: '$9.25',
        image: 'https://images.pexels.com/photos/1633525/pexels-photo-1633525.jpeg?auto=compress&cs=tinysrgb&w=400'
      }
    ]
  };

  return (
    <div className="pt-16 min-h-screen bg-cream-50">
      {/* Hero Section */}
      <section className="bg-coffee-800 text-white py-20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl font-bold mb-6">Our Menu</h1>
            <p className="text-xl text-cream-100">
              Carefully crafted beverages and fresh food made with love
            </p>
          </motion.div>
        </div>
      </section>

      {/* Menu Content */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Category Tabs */}
          <div className="flex flex-wrap justify-center mb-12 bg-white rounded-2xl p-2 shadow-lg">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                  activeCategory === category.id
                    ? 'bg-coffee-600 text-white shadow-lg'
                    : 'text-coffee-600 hover:bg-coffee-50'
                }`}
              >
                {category.icon}
                <span>{category.name}</span>
              </button>
            ))}
          </div>

          {/* Menu Items Grid */}
          <motion.div
            key={activeCategory}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {menuItems[activeCategory].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                    <span className="text-lg font-bold text-moss-600">{item.price}</span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-coffee-800 mb-2">{item.name}</h3>
                  <p className="text-coffee-600 mb-4">{item.description}</p>
                  <button 
                    onClick={() => handleAddToCart(item, activeCategory)}
                    className="w-full bg-coffee-600 text-white py-2 rounded-lg font-medium hover:bg-coffee-700 transform hover:scale-105 transition-all duration-200 shadow-lg"
                  >
                    Add to Order
                  </button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Special Notice */}
      <section className="py-16 bg-moss-100">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-coffee-800 mb-4">Made Fresh Daily</h2>
            <p className="text-lg text-coffee-600 mb-6">
              All our pastries are baked fresh every morning, and our coffee is roasted weekly to ensure the perfect flavor in every cup.
            </p>
            <div className="inline-flex items-center space-x-2 text-moss-700 font-medium">
              <Leaf className="h-5 w-5" />
              <span>Organic • Fair Trade • Locally Sourced</span>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Menu;