import React from 'react';
import { Coffee, MapPin, Phone, Mail, Instagram, Facebook, Twitter } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-coffee-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <Coffee className="h-8 w-8 text-moss-400" />
              <div>
                <span className="text-xl font-bold">Brew & Bloom</span>
                <div className="text-xs text-moss-400 -mt-1">CAFE</div>
              </div>
            </Link>
            <p className="text-cream-100 mb-4">
              Where exceptional coffee meets genuine community. Join us for artisan roasted coffee and sustainable practices.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">Home</Link></li>
              <li><Link to="/menu" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">Menu</Link></li>
              <li><Link to="/our-story" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">Our Story</Link></li>
              <li><Link to="/gallery" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">Gallery</Link></li>
              <li><Link to="/newsletter" className="text-cream-200 hover:text-moss-400 transition-colors duration-200">Newsletter</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-moss-400 mt-1 flex-shrink-0" />
                <span className="text-cream-200">1247 Elm Street<br />Portland, OR 97205</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-moss-400" />
                <span className="text-cream-200">(503) 555-BREW</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-moss-400" />
                <span className="text-cream-200">hello@brewandbloom.com</span>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Hours</h3>
            <ul className="space-y-2 text-cream-200">
              <li className="flex justify-between">
                <span>Mon - Fri</span>
                <span>6AM - 8PM</span>
              </li>
              <li className="flex justify-between">
                <span>Saturday</span>
                <span>7AM - 9PM</span>
              </li>
              <li className="flex justify-between">
                <span>Sunday</span>
                <span>7AM - 7PM</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-coffee-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-cream-200 text-sm">
            © 2025 Brew & Bloom Cafe. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-cream-200 hover:text-moss-400 text-sm transition-colors duration-200">Privacy Policy</a>
            <a href="#" className="text-cream-200 hover:text-moss-400 text-sm transition-colors duration-200">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;